You can play the video by open the "crowd_player.html". 
And a flash video player will play the mp4 file.
The caption is included inside the video, pleace open the "CC" during watching the video
Enjoy~~
Thanks for watching